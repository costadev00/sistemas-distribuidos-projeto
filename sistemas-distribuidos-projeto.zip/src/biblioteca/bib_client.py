import sys

def run():
    print('Executou ', __name__)
    print('Argumentos: ', sys.argv)