from biblioteca.gRPC import cadastro_pb2 as cadastro_pb
from biblioteca.gRPC import cadastro_pb2_grpc as cadastro_grpc

if __name__ == '__main__':
    print("Hello World!")